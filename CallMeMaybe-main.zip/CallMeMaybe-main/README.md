## CallMeMaybe
<li>Enhancer for the system Phone app.</li>

## Screenshots
| ![ss1](https://raw.githubusercontent.com/dayanch96/CallMeMaybe/refs/heads/main/Resources/ss1.png) | ![ss2](https://raw.githubusercontent.com/dayanch96/CallMeMaybe/refs/heads/main/Resources/ss2.png) | ![ss3](https://raw.githubusercontent.com/dayanch96/CallMeMaybe/refs/heads/main/Resources/ss3.png) |
| --- | --- | --- |

## Main Features
<li>Favorite contact call confirmation</li>
<li>Recent calls confirmation</li>
<li>Recent calls list settings</li>
<li>Remove unnecessary tabs</li>
<li>Rootful, Rootless and Roothide support</li>
<br>


**Long press tab bar to open Call Me Maybe settings**
