#import <UIKit/UIKit.h>

#import "./Utils/CMMUserDefaults.h"
#import "../Utils/NSBundle+CMMPrefs.h"
#import "../Headers/Private.h"
#import "../Headers/PhoneApplication.h"
#import "../Headers/MPRootViewController.h"

@interface Prefs : UITableViewController
@end
