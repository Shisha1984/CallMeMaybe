#import "MPRecentsTableViewCell.h"

@interface MPRecentsTableViewController : UIViewController
@end
