#import <UIKit/UIKit.h>
#import "PHRecentsItem.h"

@interface MPRecentsTableViewCell : UITableViewCell
@property (nonatomic, strong, readwrite) PHRecentsItem *item;
@end
