#import <Foundation/Foundation.h>

@interface PHRecentsItem : NSObject
@property (nonatomic, copy, readwrite) NSString *localizedTitle;
@property (nonatomic, copy, readwrite) NSString *localizedSubtitle;
@end
