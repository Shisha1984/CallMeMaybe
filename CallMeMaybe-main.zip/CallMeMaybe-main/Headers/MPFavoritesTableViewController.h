#import "MPFavoritesTableViewCell.h"

@interface MPFavoritesTableViewController : UIViewController
@end
