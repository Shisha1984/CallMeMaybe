#import <UIKit/UIKit.h>

@interface PhoneTabBarController : UIViewController
- (void)showFavoritesTab:(BOOL)favoritesTab recentsTab:(BOOL)recentsTab contactsTab:(BOOL)contactsTab keypadTab:(BOOL)keypadTab voicemailTab:(BOOL)voicemailTab;
@end
