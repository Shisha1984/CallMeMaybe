#import <UIKit/UIKit.h>

@interface PhoneApplication : UIApplication
@end