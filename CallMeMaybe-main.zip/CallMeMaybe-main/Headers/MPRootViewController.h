#import "PhoneTabBarController.h"

@interface MPRootViewController : UIViewController
@property (nonatomic, strong, readonly) PhoneTabBarController *baseViewController;
@end
